<?php

//MASUKAN DATA MILIK KALIAN!!
$data = "xxxxxxxx";
