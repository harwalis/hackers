######################################
# Thank You Allah Swt..              #
# Thanks My Team : Black Coder Crush #
# Thnks You All My Friends me.       #
# Thanks All Member BCC :            #
# Leader : M.Daffa                   #
# CO Founder : Mr.Tr3v!0n            #
# CO Leader : Akin                   #
# CO : Holilul Anwar                 #
# Zumbailee,Febry, Bima, Accil, Alfa #
# Ardi Bordir  Raka, Wahyu Andika.   #
# Mr.OO3T, Yulia Febriana, Sadboy,   #
# Cyto Xploit, Sazxt, Minewizard,    #
# Riki, Omest                        #
######################################
z="
";Uz='m1="';Az='a="\';Rz='1m"';Pz='\033';Sz='p1="';gz='${h}';fz='m}║ ';Oz='pu="';mz='OK  ';Iz='k="\';cz='m}╔═';nz='${b}';Cz='30;1';ez='╗"';Jz='33;1';Xz='39;1';jz='COUN';Tz='[37;';oz='║"';Ez='m="\';kz='T FA';iz='N AC';Qz='[36;';Yz='hi="';dz='════';Dz='m"';Wz='p="\';az='echo';pz='b}╚═';Vz='[38;';Gz='h="\';hz='LOGI';Zz='[40;';Mz='c="\';lz='CEBO';bz=' "${';Kz='b="\';Fz='31;1';Lz='34;1';Nz='35;1';qz='╝"';Hz='32;1';Bz='033[';
eval "$Az$Bz$Cz$Dz$z$Ez$Bz$Fz$Dz$z$Gz$Bz$Hz$Dz$z$Iz$Bz$Jz$Dz$z$Kz$Bz$Lz$Dz$z$Mz$Bz$Nz$Dz$z$Oz$Pz$Qz$Rz$z$Sz$Pz$Tz$Rz$z$Uz$Pz$Vz$Rz$z$Wz$Bz$Xz$Dz$z$Yz$Pz$Zz$Rz$z$az$bz$cz$dz$dz$dz$dz$dz$dz$ez$z$az$bz$fz$gz$hz$iz$jz$kz$lz$mz$nz$oz$z$az$bz$pz$dz$dz$dz$dz$dz$dz$qz" 
